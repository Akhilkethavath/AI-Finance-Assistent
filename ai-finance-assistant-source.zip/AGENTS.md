<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

Finance features use Lovable Cloud tables with user-scoped row policies; browser CRUD uses the generated client, while forecasts and categorization stay in client-safe helpers, and the model lab documents companion Python analysis because the React browser UI cannot import Python packages.

Personal finance questions use an authenticated server function with explicit owner filters and RLS, then deterministic calculation helpers; no generative model invents financial figures. Keep one in-memory conversation per signed-in identity and clear it on account/month transitions to avoid stale or cross-account answers; compose the chat with AI Elements.
Voice questions and spoken answers go through signed-in-only server routes under src/routes/api/voice/ that verify the bearer token before calling the AI Gateway; voice only converts speech to text and text to speech, while financial figures still come from the deterministic record-based assistant.
