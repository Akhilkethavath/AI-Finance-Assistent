import { describe, expect, it, vi } from "vitest";

const auth = vi.hoisted(() => ({ requireSupabaseAuth: {} }));
const boundary = vi.hoisted(() => ({ middleware: vi.fn(), headers: vi.fn() }));
vi.mock("@/integrations/supabase/auth-middleware", () => auth);
vi.mock("@tanstack/react-start/server", () => ({ setResponseHeader: boundary.headers }));
vi.mock("@tanstack/react-start", () => ({
  createServerFn: () => ({
    middleware: (middleware: unknown[]) => {
      boundary.middleware(middleware);
      return { inputValidator: () => ({ handler: (handler: unknown) => handler }) };
    },
  }),
}));
import { askPersonalFinance } from "./personal-finance.functions";

describe("private finance retrieval", () => {
  it("authenticates and filters both tables by the verified owner, never the supplied account", async () => {
    const filters: unknown[][] = [];
    const client = {
      from: (table: string) => ({
        select: () => ({
          eq: (column: string, owner: string) => {
            filters.push([table, column, owner]);
            return { order: () => ({ range: async () => ({ data: [], error: null }) }) };
          },
        }),
      }),
    };
    const handler = askPersonalFinance as unknown as (input: unknown) => Promise<unknown>;
    await handler({
      data: { question: "How much did I spend?", month: "2026-11", userId: "another-account" },
      context: { userId: "verified-owner", supabase: client },
    });
    expect(boundary.middleware).toHaveBeenCalledWith([auth.requireSupabaseAuth]);
    expect(filters).toEqual([
      ["transactions", "user_id", "verified-owner"],
      ["budgets", "user_id", "verified-owner"],
    ]);
    expect(boundary.headers).toHaveBeenCalledWith("Cache-Control", "no-store");
  });
});
