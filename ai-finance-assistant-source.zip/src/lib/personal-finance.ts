import {
  amountForMonth,
  budgetStatus,
  categorySpend,
  chatbotReply,
  currentMonth,
  forecastSpending,
  formatAmount,
  shiftMonth,
  type FinanceBudget,
  type FinanceTransaction,
} from "./finance";

export function analyzePersonalFinance(
  transactions: FinanceTransaction[],
  budgets: FinanceBudget[],
  month: string,
  today = new Date(),
) {
  const income = amountForMonth(transactions, month, "income");
  const expenses = amountForMonth(transactions, month, "expense");
  return {
    month,
    income,
    expenses,
    remaining: income - expenses,
    categories: categorySpend(transactions, month),
    budgets: budgetStatus(budgets, transactions, month),
    forecast: forecastSpending(transactions, today),
    recordCount: transactions.filter((row) => row.transaction_date.startsWith(month)).length,
  };
}

export function personalFinanceReply(
  question: string,
  transactions: FinanceTransaction[],
  budgets: FinanceBudget[],
  selectedMonth: string,
  today = new Date(),
) {
  const text = question.toLowerCase();
  const explicitMonth = question.match(/\b(\d{4}-(?:0[1-9]|1[0-2]))\b/)?.[1];
  const month =
    explicitMonth ??
    (/this month/.test(text)
      ? currentMonth(today)
      : /last month/.test(text)
        ? shiftMonth(currentMonth(today), -1)
        : selectedMonth);
  const facts = analyzePersonalFinance(transactions, budgets, month, today);
  const money = (value: number) => `₹${formatAmount(value)}`;
  const summary = `For ${month}, your recorded income is ${money(facts.income)}, expenses are ${money(facts.expenses)}, and income minus expenses is ${money(facts.remaining)}.`;
  const caution =
    " These are recorded amounts, not your bank balance or a guarantee of future savings.";
  if (/invest|stock|tax|loan/.test(text)) return { text: chatbotReply(question), facts };
  if (/\bhow.*(add|record|edit|delete)|privacy|password|security/.test(text))
    return { text: chatbotReply(question), facts };
  if (/forecast|predict|next month|estimate/.test(text)) {
    const estimate = facts.forecast.estimates.find(
      (row) => row.month === shiftMonth(currentMonth(today), 1),
    );
    const modelName = (
      {
        linear: "linear regression",
        polynomial: "nonlinear polynomial regression",
        multilinear: "multilinear regression",
        mean: "historical average",
      } as Record<string, string>
    )[facts.forecast.model ?? ""];
    return {
      text: estimate
        ? `For ${estimate.month}, your estimated expenses are ${money(estimate.estimate)} using ${modelName} and ${facts.forecast.monthsUsed} completed months.${estimate.low !== null && estimate.high !== null ? ` Validation-error range: ${money(estimate.low)}–${money(estimate.high)}.` : " This is only a simple average; more history is needed for regression."} ${facts.forecast.disclaimer}`
        : (facts.forecast.message ??
          "More completed monthly records are needed for a next-month estimate."),
      facts,
    };
  }
  if (!facts.recordCount)
    return {
      text: `You have no recorded transactions for ${month}. I cannot determine your spending or savings for that month yet.`,
      facts,
    };
  if (/budget|exceed|limit/.test(text)) {
    return {
      text: facts.budgets.length
        ? facts.budgets
            .map(
              (budget) =>
                `${budget.category === "ALL" ? "Overall" : budget.category} budget: ${money(budget.spent)} spent of ${money(budget.limit_amount)} (${formatAmount(budget.usedPct)}%). ${budget.status === "exceeded" ? `Exceeded by ${money(-budget.remaining)}.` : budget.status === "warning" ? `Warning: ${money(budget.remaining)} remaining.` : `${money(budget.remaining)} remaining.`}`,
            )
            .join("\n\n")
        : `${summary} No budgets are set for ${month}, so I cannot check a budget limit.`,
      facts,
    };
  }
  if (/save|saving/.test(text)) {
    const amountText = question
      .replace(explicitMonth ?? "", "")
      .match(/(?:₹|rs\.?\s*|inr\s*)?([\d,]+(?:\.\d{1,2})?)/i)?.[1];
    const goal = amountText ? Number(amountText.replaceAll(",", "")) : undefined;
    if (goal !== undefined && Number.isFinite(goal) && goal > 0) {
      const overall = facts.budgets.find((budget) => budget.category === "ALL");
      const savings = {
        goal,
        covered: facts.remaining >= goal,
        remainderAfterGoal: facts.remaining - goal,
        additionalSpendingLimit: Math.max(
          0,
          Math.min(overall?.remaining ?? Infinity, facts.remaining - goal),
        ),
      };
      return {
        text: `${summary} ${facts.remaining >= goal ? `Your recorded surplus covers a ${money(goal)} savings goal, leaving ${money(facts.remaining - goal)} for additional expenses.` : `You are ${money(goal - facts.remaining)} short of a ${money(goal)} savings goal based on recorded income and expenses.`}${overall ? ` Your overall budget has ${money(overall.remaining)} remaining; to retain this goal, additional spending should stay within ${money(Math.max(0, Math.min(overall.remaining, facts.remaining - goal)))}.` : " No overall budget is set for this month."}${caution}`,
        facts,
        savings,
      };
    }
    const top = facts.categories[0];
    return {
      text: `${summary}${top ? ` Your largest recorded expense category is ${top.category} at ${money(top.amount)}. A 10% reduction there would retain ${money(top.amount * 0.1)} if those expenses are flexible; review necessities before cutting.` : " No expenses are recorded, so there is no spending pattern to review."}${caution}`,
      facts,
    };
  }
  if (/most|going|categor|breakdown|where|pattern/.test(text)) {
    const top = facts.categories[0];
    return {
      text: top
        ? `${summary} Most of your recorded spending is in ${top.category}: ${money(top.amount)} (${formatAmount((top.amount / facts.expenses) * 100)}% of expenses).\n\n${facts.categories.map((row) => `${row.category}: ${money(row.amount)}`).join("\n")}\n\nKeep tracking transactions for more reliable insights.`
        : `${summary} There are no recorded expenses to break down.`,
      facts,
    };
  }
  if (/spen|expense|income|balance|left|remaining|overview|\bhi\b|hello/.test(text))
    return { text: summary + caution, facts };
  return {
    text: `${summary} I can calculate recorded spending, category totals, savings goals, budget usage, and statistical forecasts. Professional investment, tax, and loan advice is outside this assistant's scope.`,
    facts,
  };
}
