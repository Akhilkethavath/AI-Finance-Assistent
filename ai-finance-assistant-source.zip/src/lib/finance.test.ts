import { describe, expect, it } from "vitest";

import {
  budgetStatus,
  cleanDescription,
  forecastSpending,
  predictExpense,
  validateTransactionDraft,
  type FinanceBudget,
  type FinanceTransaction,
} from "./finance";

describe("finance behavior preserved from the source app", () => {
  it("cleans transaction descriptions before model tokenization", () => {
    expect(cleanDescription("Swiggy DINNER 450!  ")).toBe("swiggy dinner");
  });

  it("predicts Food for a Swiggy dinner description", () => {
    expect(predictExpense("swiggy dinner").category).toBe("Food");
  });

  it("predicts Transport for an Uber ride description", () => {
    expect(predictExpense("uber ride").category).toBe("Transport");
  });

  it("falls back to Other and flags text the model does not know", () => {
    expect(predictExpense("zzzz qqqq")).toMatchObject({ category: "Other", confidence: 0, lowConfidence: true, knownWords: false });
  });

  it("shows a budget warning at 80 percent and exceeded above 100 percent", () => {
    const transactions: FinanceTransaction[] = [
      { id: "one", transaction_date: "2026-06-10", description: "groceries", amount: 80, transaction_type: "expense", category: "Food" },
      { id: "two", transaction_date: "2026-06-11", description: "bus pass", amount: 25, transaction_type: "expense", category: "Transport" },
    ];
    const budgets: FinanceBudget[] = [
      { id: "food", month_start: "2026-06-01", category: "Food", limit_amount: 100 },
      { id: "all", month_start: "2026-06-01", category: "ALL", limit_amount: 100 },
    ];

    expect(budgetStatus(budgets, transactions, "2026-06").map(({ category, status }) => [category, status])).toEqual([
      ["ALL", "exceeded"],
      ["Food", "warning"],
    ]);
  });

  it("keeps a budget at exactly 100 percent in warning rather than exceeded", () => {
    const transactions: FinanceTransaction[] = [
      { id: "one", transaction_date: "2026-06-10", description: "groceries", amount: 100, transaction_type: "expense", category: "Food" },
    ];
    const budgets: FinanceBudget[] = [
      { id: "all", month_start: "2026-06-01", category: "ALL", limit_amount: 100 },
    ];
    expect(budgetStatus(budgets, transactions, "2026-06")[0]?.status).toBe("warning");
  });

  it("uses a simple average until three completed months are available", () => {
    const transactions: FinanceTransaction[] = [
      { id: "one", transaction_date: "2026-03-10", description: "market", amount: 100, transaction_type: "expense", category: "Food" },
      { id: "two", transaction_date: "2026-04-10", description: "market", amount: 200, transaction_type: "expense", category: "Food" },
    ];
    const forecast = forecastSpending(transactions, new Date(2026, 5, 15));
    expect(forecast.status).toBe("insufficient_data");
    expect(forecast.estimates.map(({ estimate }) => estimate)).toEqual([150, 150]);
  });

  it("compares linear, nonlinear, and multilinear forecast models", () => {
    const transactions: FinanceTransaction[] = [];
    for (let index = 0; index < 14; index += 1) {
      const monthDate = new Date(2025, 0 + index, 10);
      const month = `${monthDate.getFullYear()}-${String(monthDate.getMonth() + 1).padStart(2, "0")}`;
      transactions.push({ id: `expense-${index}`, transaction_date: `${month}-10`, description: "monthly expenses", amount: 200 + index * 9 + (index % 3) * 14, transaction_type: "expense", category: "Bills" });
      transactions.push({ id: `income-${index}`, transaction_date: `${month}-12`, description: "monthly income", amount: 1600 + index * 12, transaction_type: "income", category: "Income" });
    }

    const forecast = forecastSpending(transactions, new Date(2026, 2, 1));
    expect(forecast.candidates?.map(({ model }) => model)).toEqual(["linear", "polynomial", "multilinear", "mean"]);
    expect(forecast.candidates?.every(({ mae, rmse }) => Number.isFinite(mae) && Number.isFinite(rmse))).toBe(true);
  });

  it("rejects transaction amounts above 1,000,000,000", () => {
    expect(validateTransactionDraft({ transaction_date: "2026-06-15", description: "Rent", amount: 1_000_000_000.01 }, new Date(2026, 5, 15)).valid).toBe(false);
  });

  it("accepts an amount of exactly 1,000,000,000", () => {
    expect(validateTransactionDraft({ transaction_date: "2026-06-15", description: "Rent", amount: 1_000_000_000 }, new Date(2026, 5, 15)).valid).toBe(true);
  });

  it("rejects transactions dated before 2000", () => {
    expect(validateTransactionDraft({ transaction_date: "1999-12-31", description: "Rent", amount: 100 }, new Date(2026, 5, 15)).valid).toBe(false);
  });

  it("accepts a transaction date exactly one year and one day ahead", () => {
    expect(validateTransactionDraft({ transaction_date: "2027-06-16", description: "Advance", amount: 100 }, new Date(2026, 5, 15)).valid).toBe(true);
  });

  it("rejects dates beyond the one-year-and-one-day window", () => {
    expect(validateTransactionDraft({ transaction_date: "2027-06-17", description: "Advance", amount: 100 }, new Date(2026, 5, 15)).valid).toBe(false);
  });

  it("allows descriptions up to 200 characters and rejects longer ones", () => {
    const date = "2026-06-15";
    const today = new Date(2026, 5, 15);
    expect(validateTransactionDraft({ transaction_date: date, description: "x".repeat(200), amount: 100 }, today).valid).toBe(true);
    expect(validateTransactionDraft({ transaction_date: date, description: "x".repeat(201), amount: 100 }, today).valid).toBe(false);
  });
});