import { createClient } from "@supabase/supabase-js";

const GATEWAY_URL = "https://ai.gateway.lovable.dev";
const TRANSCRIBE_MODEL = "openai/gpt-transcribe";
const SPEECH_MODEL = "google/gemini-3.1-flash-tts-preview";
const SPEECH_VOICE = "Kore";
export const MAX_AUDIO_BYTES = 10 * 1024 * 1024;
export const MAX_SPEECH_CHARS = 2000;

function gatewayKey() {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("Voice is not configured.");
  return key;
}

/** Returns the signed-in user's id for a valid bearer token, otherwise null. */
export async function verifyVoiceCaller(request: Request): Promise<string | null> {
  const header = request.headers.get("authorization") ?? "";
  if (!header.startsWith("Bearer ")) return null;
  const token = header.slice(7).trim();
  if (token.split(".").length !== 3) return null;
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return null;
  const client = createClient(url, key, {
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await client.auth.getClaims(token);
  return error || !data?.claims?.sub ? null : data.claims.sub;
}

export function transcribeAudio(file: File) {
  const form = new FormData();
  form.append("model", TRANSCRIBE_MODEL);
  form.append("file", file, file.name);
  form.append("response_format", "json");
  form.append("stream", "true");
  form.append("keywords", "rupees, budget, savings, expenses, income, forecast");
  return fetch(`${GATEWAY_URL}/v1/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${gatewayKey()}`, "X-Lovable-AIG-SDK": "fetch" },
    body: form,
  });
}

export function requestSpeech(text: string, signal?: AbortSignal) {
  return fetch(`${GATEWAY_URL}/v1/audio/speech`, {
    method: "POST",
    headers: { Authorization: `Bearer ${gatewayKey()}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({
      model: SPEECH_MODEL,
      contents: [{ role: "user", parts: [{ text: `Read this clearly in a calm, friendly voice: ${text}` }] }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: SPEECH_VOICE } } },
      },
      stream_format: "sse",
    }),
    ...(signal ? { signal } : {}),
  });
}
