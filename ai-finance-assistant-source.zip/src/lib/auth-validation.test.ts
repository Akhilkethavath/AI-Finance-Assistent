import { describe, expect, it } from "vitest";
import { signupPasswordError } from "./auth-validation";

describe("sign-up re-enter password", () => {
  it("blocks account creation when the re-entered password differs", () => {
    expect(signupPasswordError("Secret123!", "Secret124!")).not.toBeNull();
  });
  it("allows account creation when both passwords match", () => {
    expect(signupPasswordError("Secret123!", "Secret123!")).toBeNull();
  });
});
