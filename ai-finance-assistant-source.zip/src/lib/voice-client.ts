import { createParser } from "eventsource-parser";

const MAX_RECORDING_SECONDS = 60;

function encodeWav(chunks: readonly Float32Array[], sampleRate: number): Blob {
  const length = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const bytes = new ArrayBuffer(44 + length * 2);
  const view = new DataView(bytes);
  const tag = (offset: number, value: string) => {
    for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i));
  };
  tag(0, "RIFF");
  view.setUint32(4, 36 + length * 2, true);
  tag(8, "WAVE");
  tag(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  tag(36, "data");
  view.setUint32(40, length * 2, true);
  let offset = 44;
  for (const chunk of chunks)
    for (const value of chunk) {
      const sample = Math.max(-1, Math.min(1, value));
      view.setInt16(offset, sample * (sample < 0 ? 32768 : 32767), true);
      offset += 2;
    }
  return new Blob([bytes], { type: "audio/wav" });
}

export type Recording = { stop: () => Promise<File>; cancel: () => void };

/** Records microphone audio as a complete WAV file (max 60 seconds of audio is kept). */
export async function startRecording(): Promise<Recording> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  let context: AudioContext | undefined;
  try {
    context = new AudioContext();
    await context.resume();
    const audioContext = context;
    const source = audioContext.createMediaStreamSource(stream);
    const node = audioContext.createScriptProcessor(4096, 1, 1);
    const chunks: Float32Array[] = [];
    const maxSamples = audioContext.sampleRate * MAX_RECORDING_SECONDS;
    let samples = 0;
    node.onaudioprocess = (event) => {
      if (samples >= maxSamples) return;
      const chunk = new Float32Array(event.inputBuffer.getChannelData(0));
      samples += chunk.length;
      chunks.push(chunk);
    };
    source.connect(node);
    node.connect(audioContext.destination);
    let stopped = false;
    const release = async () => {
      stopped = true;
      stream.getTracks().forEach((track) => track.stop());
      node.disconnect();
      source.disconnect();
      node.onaudioprocess = null;
      if (audioContext.state !== "closed") await audioContext.close();
    };
    return {
      async stop() {
        if (stopped) throw new Error("Recording already stopped");
        const sampleRate = audioContext.sampleRate;
        await release();
        const blob = encodeWav(chunks, sampleRate);
        if (blob.size < 2048) throw new Error("We couldn't hear anything. Please try again.");
        return new File([blob], "question.wav", { type: "audio/wav" });
      },
      cancel() {
        if (!stopped) void release();
      },
    };
  } catch (error) {
    stream.getTracks().forEach((track) => track.stop());
    await context?.close();
    throw error;
  }
}

async function errorMessage(response: Response, fallback: string) {
  try {
    const body = (await response.json()) as { error?: string | { message?: string }; message?: string };
    if (typeof body.error === "string") return body.error;
    return body.error?.message ?? body.message ?? fallback;
  } catch {
    return fallback;
  }
}

/** Uploads a recording and returns the final transcript. */
export async function transcribeRecording(file: File, accessToken: string): Promise<string> {
  const form = new FormData();
  form.append("file", file, file.name);
  const response = await fetch("/api/voice/transcribe", { method: "POST", headers: { Authorization: `Bearer ${accessToken}` }, body: form });
  if (!response.ok || !response.body) throw new Error(await errorMessage(response, "Voice question could not be understood. Please try again."));
  let text = "";
  let finalText: string | null = null;
  let failure: string | null = null;
  const parser = createParser({
    onEvent(event) {
      if (event.data === "[DONE]") return;
      const payload = JSON.parse(event.data) as { type?: string; delta?: string; text?: string; error?: { message?: string } };
      if (payload.type === "error" || payload.error) failure = payload.error?.message ?? "Voice question could not be understood.";
      else if (payload.type === "transcript.text.delta" && payload.delta) text += payload.delta;
      else if (payload.type === "transcript.text.done") finalText = payload.text ?? text;
    },
  });
  const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();
  while (true) {
    const next = await reader.read();
    if (next.done) break;
    parser.feed(next.value);
  }
  if (failure) throw new Error(failure);
  if (finalText === null) throw new Error("Voice question was cut off. Please try again.");
  const transcript = (finalText as string).trim();
  if (!transcript) throw new Error("We couldn't hear a question. Please try again.");
  return transcript;
}

/** Turns a written answer into plain sentences suitable for reading aloud. */
export function toSpokenText(markdown: string) {
  return markdown
    .replace(/[*_`#>|]/g, "")
    .replace(/₹\s?/g, "rupees ")
    .replace(/^\s*[-•]\s+/gm, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 2000);
}

/** Streams and plays a spoken answer. Resolves after playback ends or is stopped. */
export async function speakText(text: string, accessToken: string, signal: AbortSignal): Promise<void> {
  const context = new AudioContext({ sampleRate: 24000 });
  const sources = new Set<AudioBufferSourceNode>();
  let playhead = 0;
  let pending = new Uint8Array(0);
  let completed = false;
  let samplesPlayed = 0;
  let failure: string | null = null;
  const stopAll = () => {
    for (const source of sources) source.stop();
  };
  signal.addEventListener("abort", stopAll, { once: true });
  let playback: Promise<void> = Promise.resolve();
  try {
    if (context.state === "suspended") await context.resume();
    const response = await fetch("/api/voice/speak", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify({ text }),
      signal,
    });
    if (!response.ok || !response.body) throw new Error(await errorMessage(response, "The answer could not be read aloud."));
    const parser = createParser({
      onEvent(event) {
        if (failure || event.data === "[DONE]") return;
        const payload = JSON.parse(event.data) as { type: string; audio?: string; error?: unknown };
        if (payload.type === "error" || payload.error) {
          failure = "The answer could not be read aloud.";
          return;
        }
        if (payload.type === "speech.audio.done") {
          completed = true;
          return;
        }
        if (payload.type !== "speech.audio.delta" || !payload.audio) return;
        const incoming = Uint8Array.from(atob(payload.audio), (c) => c.charCodeAt(0));
        const bytes = new Uint8Array(pending.length + incoming.length);
        bytes.set(pending);
        bytes.set(incoming, pending.length);
        const usable = bytes.length - (bytes.length % 2);
        const view = new DataView(bytes.buffer);
        const samples = new Float32Array(usable / 2);
        for (let i = 0; i < samples.length; i++) samples[i] = view.getInt16(i * 2, true) / 32768;
        pending = bytes.slice(usable);
        if (!samples.length) return;
        samplesPlayed += samples.length;
        const buffer = context.createBuffer(1, samples.length, 24000);
        buffer.copyToChannel(samples, 0);
        const source = context.createBufferSource();
        source.buffer = buffer;
        source.connect(context.destination);
        sources.add(source);
        playback = new Promise<void>((resolve) => {
          source.onended = () => {
            sources.delete(source);
            resolve();
          };
        });
        playhead = Math.max(playhead, context.currentTime + 0.05);
        source.start(playhead);
        playhead += buffer.duration;
      },
    });
    const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      parser.feed(next.value);
    }
    if (failure) throw new Error(failure);
    if (!completed || !samplesPlayed) throw new Error("The answer could not be read aloud completely.");
    await playback;
  } catch (error) {
    if (signal.aborted) return;
    throw error;
  } finally {
    signal.removeEventListener("abort", stopAll);
    stopAll();
    await context.close();
  }
}
