/** Returns a message when the sign-up password and its re-entry differ, otherwise null. */
export function signupPasswordError(password: string, confirmPassword: string): string | null {
  return password === confirmPassword ? null : "Passwords don't match. Please re-enter the same password.";
}
