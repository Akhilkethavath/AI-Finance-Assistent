import modelJson from "@/assets/finance-category-model.json";

export const CATEGORIES = [
  "Food",
  "Transport",
  "Shopping",
  "Bills",
  "Entertainment",
  "Health",
  "Education",
  "Other",
] as const;

export type Category = (typeof CATEGORIES)[number];
export type TransactionType = "income" | "expense";

export type FinanceTransaction = {
  id: string;
  transaction_date: string;
  description: string;
  amount: number;
  transaction_type: TransactionType;
  category: string;
};

export type FinanceBudget = {
  id: string;
  month_start: string;
  category: string;
  limit_amount: number;
};

type CategoryModel = {
  classes: string[];
  vectorizer: {
    ngram_max: number;
    vocab: Record<string, number>;
    idf: number[];
  };
  weights: number[][];
};

export type SpendingForecast = {
  monthsUsed: number;
  disclaimer: string;
  status: string;
  model?: string;
  message?: string;
  candidates?: { model: string; mae: number; rmse: number; r2: number | null }[];
  estimates: { month: string; estimate: number; low: number | null; high: number | null }[];
};

export function validateTransactionDraft(input: { transaction_date: string; description: string; amount: string | number }, today = new Date()) {
  const amount = Number(input.amount);
  const date = new Date(`${input.transaction_date}T00:00:00Z`);
  const normalizedDate = Number.isNaN(date.getTime()) ? "" : date.toISOString().slice(0, 10);
  const latestDate = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate() + 366)).toISOString().slice(0, 10);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 1_000_000_000) {
    return { valid: false, message: "Amount must be greater than zero and no more than 1,000,000,000." };
  }
  if (!normalizedDate || normalizedDate !== input.transaction_date || normalizedDate < "2000-01-01" || normalizedDate > latestDate) {
    return { valid: false, message: "Date must be valid and between 2000 and one year from today." };
  }
  if (!input.description.trim() || input.description.trim().length > 200) {
    return { valid: false, message: "Description is required and must be no longer than 200 characters." };
  }
  return { valid: true, message: "" };
}

const model = modelJson as CategoryModel;
const LOW_CONFIDENCE = 0.4;
const aliases: Record<string, Category> = {
  groceries: "Food",
  dining: "Food",
  "food & dining": "Food",
  restaurant: "Food",
  travel: "Transport",
  fuel: "Transport",
  commute: "Transport",
  utilities: "Bills",
  bill: "Bills",
  rent: "Bills",
  movies: "Entertainment",
  leisure: "Entertainment",
  medical: "Health",
  healthcare: "Health",
  fitness: "Health",
  learning: "Education",
  school: "Education",
  misc: "Other",
  miscellaneous: "Other",
};

export function cleanDescription(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function resolveCategory(value: string | null | undefined): Category | null {
  if (!value) return null;
  const key = value.trim().toLowerCase();
  return CATEGORIES.find((category) => category.toLowerCase() === key) ?? aliases[key] ?? null;
}

export function predictExpense(description: string) {
  const words = cleanDescription(description).split(" ").filter(Boolean);
  const tokens = [...words];
  if (model.vectorizer.ngram_max >= 2) {
    for (let index = 0; index < words.length - 1; index += 1) {
      tokens.push(`${words[index]} ${words[index + 1]}`);
    }
  }

  const counts = new Map<number, number>();
  for (const token of tokens) {
    const index = model.vectorizer.vocab[token];
    if (index !== undefined) counts.set(index, (counts.get(index) ?? 0) + 1);
  }

  if (counts.size === 0) {
    return {
      category: "Other" as Category,
      confidence: 0,
      lowConfidence: true,
      knownWords: false,
      alternatives: [] as { category: string; confidence: number }[],
    };
  }

  let normSquared = 0;
  const vector = new Map<number, number>();
  for (const [index, count] of counts) {
    const value = (1 + Math.log(count)) * (model.vectorizer.idf[index] ?? 0);
    vector.set(index, value);
    normSquared += value * value;
  }
  const norm = Math.sqrt(normSquared) || 1;
  const scores = model.classes.map((_, classIndex) => {
    let score = model.weights[0]?.[classIndex] ?? 0;
    for (const [index, value] of vector) {
      score += (value / norm) * (model.weights[index + 1]?.[classIndex] ?? 0);
    }
    return score;
  });
  const positive = scores.map((score) => Math.max(score, 0));
  const total = positive.reduce((sum, value) => sum + value, 0);
  const order = scores.map((_, index) => index).sort((a, b) => (scores[b] ?? 0) - (scores[a] ?? 0));
  const winner = order[0] ?? model.classes.indexOf("Other");
  const confidence = total > 0 ? (positive[winner] ?? 0) / total : 0;

  return {
    category: (model.classes[winner] ?? "Other") as Category,
    confidence,
    lowConfidence: confidence < LOW_CONFIDENCE,
    knownWords: true,
    alternatives: order.slice(1, 3).map((index) => ({
      category: model.classes[index] ?? "Other",
      confidence: total > 0 ? (positive[index] ?? 0) / total : 0,
    })),
  };
}

export function monthKey(date: string) {
  return date.slice(0, 7);
}

export function currentMonth(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export function monthStart(month: string) {
  return `${month}-01`;
}

export function shiftMonth(month: string, delta: number) {
  const [yearText, monthText] = month.split("-");
  const date = new Date(Number(yearText), Number(monthText) - 1 + delta, 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export function formatAmount(amount: number, compact = false) {
  return new Intl.NumberFormat("en-IN", {
    maximumFractionDigits: compact ? 0 : 2,
    notation: compact ? "compact" : "standard",
  }).format(amount);
}

export function amountForMonth(transactions: FinanceTransaction[], month: string, type?: TransactionType) {
  return transactions
    .filter((transaction) => monthKey(transaction.transaction_date) === month)
    .filter((transaction) => !type || transaction.transaction_type === type)
    .reduce((sum, transaction) => sum + Number(transaction.amount), 0);
}

export function categorySpend(transactions: FinanceTransaction[], month: string) {
  const totals = new Map<string, number>();
  for (const transaction of transactions) {
    if (transaction.transaction_type !== "expense" || monthKey(transaction.transaction_date) !== month) continue;
    totals.set(transaction.category, (totals.get(transaction.category) ?? 0) + Number(transaction.amount));
  }
  return [...totals.entries()]
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);
}

export function budgetStatus(
  budgets: FinanceBudget[],
  transactions: FinanceTransaction[],
  month: string,
) {
  const spend = categorySpend(transactions, month);
  const overall = spend.reduce((sum, row) => sum + row.amount, 0);
  return budgets
    .filter((budget) => budget.month_start === monthStart(month))
    .map((budget) => {
      const spent = budget.category === "ALL" ? overall : (spend.find((row) => row.category === budget.category)?.amount ?? 0);
      const limit = Number(budget.limit_amount);
      const usedPct = limit > 0 ? (spent / limit) * 100 : 0;
      return {
        ...budget,
        spent,
        usedPct,
        remaining: limit - spent,
        status: usedPct > 100 ? "exceeded" : usedPct >= 80 ? "warning" : "ok",
      };
    })
    .sort((a, b) => (a.category === "ALL" ? -1 : b.category === "ALL" ? 1 : a.category.localeCompare(b.category)));
}

function solve(matrix: number[][], target: number[]) {
  const size = target.length;
  const augmented = matrix.map((row, index) => [...row, target[index] ?? 0]);
  for (let column = 0; column < size; column += 1) {
    let pivot = column;
    for (let row = column + 1; row < size; row += 1) {
      if (Math.abs(augmented[row]?.[column] ?? 0) > Math.abs(augmented[pivot]?.[column] ?? 0)) pivot = row;
    }
    const pivotRow = augmented[pivot];
    const currentRow = augmented[column];
    if (!pivotRow || !currentRow) return Array<number>(size).fill(0);
    augmented[column] = pivotRow;
    augmented[pivot] = currentRow;
    const activeRow = augmented[column];
    if (!activeRow) return Array<number>(size).fill(0);
    const divisor = activeRow[column] ?? 0;
    if (Math.abs(divisor) < 1e-10) continue;
    for (let cell = column; cell <= size; cell += 1) {
      activeRow[cell] = (activeRow[cell] ?? 0) / divisor;
    }
    for (let row = 0; row < size; row += 1) {
      if (row === column) continue;
      const targetRow = augmented[row];
      if (!targetRow) continue;
      const factor = targetRow[column] ?? 0;
      for (let cell = column; cell <= size; cell += 1) {
        targetRow[cell] = (targetRow[cell] ?? 0) - factor * (activeRow[cell] ?? 0);
      }
    }
  }
  return augmented.map((row, index) => row[size] ?? (index === 0 ? 0 : 0));
}

function fitRegression(features: number[][], target: number[], alpha = 0) {
  const width = features[0]?.length ?? 0;
  const gram = Array.from({ length: width + 1 }, () => Array<number>(width + 1).fill(0));
  const rhs = Array<number>(width + 1).fill(0);
  for (let row = 0; row < features.length; row += 1) {
    const values = [1, ...(features[row] ?? [])];
    for (let i = 0; i < values.length; i += 1) {
      const valueI = values[i] ?? 0;
      rhs[i] = (rhs[i] ?? 0) + valueI * (target[row] ?? 0);
      const matrixRow = gram[i];
      if (!matrixRow) continue;
      for (let j = 0; j < values.length; j += 1) {
        matrixRow[j] = (matrixRow[j] ?? 0) + valueI * (values[j] ?? 0);
      }
    }
  }
  for (let i = 1; i < gram.length; i += 1) {
    const row = gram[i];
    if (row) row[i] = (row[i] ?? 0) + alpha;
  }
  return solve(gram, rhs);
}

function predictRegression(coefficients: number[], features: number[]) {
  return coefficients.reduce((sum, coefficient, index) => sum + coefficient * (index === 0 ? 1 : (features[index - 1] ?? 0)), 0);
}

type ForecastPredictor = (index: number, previous?: number, incomeAvg?: number, month?: number) => number;

function fitCandidate(kind: string, expenses: number[], incomes: number[], end: number, calendarMonths: number[]): ForecastPredictor | null {
  if (kind === "mean") {
    const mean = expenses.slice(0, end).reduce((sum, value) => sum + value, 0) / Math.max(end, 1);
    return (_index) => mean;
  }
  if (kind === "linear" && end >= 2) {
    const coeff = fitRegression(expenses.slice(0, end).map((_, index) => [index]), expenses.slice(0, end));
    return (index: number) => predictRegression(coeff, [index]);
  }
  if (kind === "polynomial" && end >= 4) {
    const center = (end - 1) / 2;
    const scale = Math.sqrt(expenses.slice(0, end).reduce((sum, _, index) => sum + (index - center) ** 2, 0) / end) || 1;
    const coeff = fitRegression(
      expenses.slice(0, end).map((_, index) => {
        const value = (index - center) / scale;
        return [value, value * value];
      }),
      expenses.slice(0, end),
      1e-6,
    );
    return (index: number) => {
      const value = (index - center) / scale;
      return predictRegression(coeff, [value, value * value]);
    };
  }
  if (kind === "multilinear" && end >= 6) {
    const seasonal = end >= 12;
    const features = [] as number[][];
    const targets = [] as number[];
    for (let index = 1; index < end; index += 1) {
      const incomeWindow = incomes.slice(Math.max(0, index - 3), index);
      const avgIncome = incomeWindow.reduce((sum, value) => sum + value, 0) / Math.max(incomeWindow.length, 1);
      const row = [index, expenses[index - 1] ?? 0, avgIncome];
      if (seasonal) {
        const angle = (2 * Math.PI * (calendarMonths[index] ?? 1)) / 12;
        row.push(Math.sin(angle), Math.cos(angle));
      }
      features.push(row);
      targets.push(expenses[index] ?? 0);
    }
    const coefficients = fitRegression(features, targets, 1);
    return (index: number, previous = 0, incomeAvg = 0, month = 1) => {
      const row = [index, previous, incomeAvg];
      if (seasonal) {
        const angle = (2 * Math.PI * month) / 12;
        row.push(Math.sin(angle), Math.cos(angle));
      }
      return predictRegression(coefficients, row);
    };
  }
  return null;
}

function modelMetrics(actual: number[], predicted: number[]) {
  const errors = actual.map((value, index) => value - (predicted[index] ?? 0));
  const mae = errors.reduce((sum, value) => sum + Math.abs(value), 0) / Math.max(errors.length, 1);
  const rmse = Math.sqrt(errors.reduce((sum, value) => sum + value * value, 0) / Math.max(errors.length, 1));
  const mean = actual.reduce((sum, value) => sum + value, 0) / Math.max(actual.length, 1);
  const total = actual.reduce((sum, value) => sum + (value - mean) ** 2, 0);
  const residual = errors.reduce((sum, value) => sum + value * value, 0);
  return { mae, rmse, r2: total > 0 && actual.length >= 2 ? 1 - residual / total : null };
}

function completedMonthlyTotals(transactions: FinanceTransaction[], today: Date) {
  if (transactions.length === 0) return [] as { month: string; income: number; expense: number }[];
  const months = transactions.map((transaction) => monthKey(transaction.transaction_date)).sort();
  const first = months[0];
  const current = currentMonth(today);
  const last = months[months.length - 1];
  if (!first || !last || first >= current) return [];
  const out = [] as { month: string; income: number; expense: number }[];
  for (let month = first; month <= last && month < current; month = shiftMonth(month, 1)) {
    out.push({
      month,
      income: amountForMonth(transactions, month, "income"),
      expense: amountForMonth(transactions, month, "expense"),
    });
  }
  return out;
}

export function forecastSpending(transactions: FinanceTransaction[], today = new Date()): SpendingForecast {
  const monthly = completedMonthlyTotals(transactions, today);
  const monthsUsed = monthly.length;
  const base = { monthsUsed, disclaimer: "This is a statistical estimate from past spending, not a guaranteed value or financial advice." };
  if (monthsUsed === 0) {
    return { ...base, status: "insufficient_data", estimates: [] as { month: string; estimate: number; low: number | null; high: number | null }[], message: "No completed months of data yet. Add transactions to get a spending estimate." };
  }
  const expenses = monthly.map((row) => row.expense);
  const incomes = monthly.map((row) => row.income);
  const lastMonth = monthly[monthsUsed - 1]?.month ?? currentMonth(today);
  if (monthsUsed < 3) {
    const average = expenses.reduce((sum, value) => sum + value, 0) / monthsUsed;
    return {
      ...base,
      status: "insufficient_data",
      model: "mean",
      message: `Only ${monthsUsed} completed month(s) of data — at least 3 are needed for a regression forecast. Showing your simple average instead.`,
      estimates: [1, 2].map((step) => ({ month: shiftMonth(lastMonth, step), estimate: average, low: null, high: null })),
    };
  }

  const calendarMonths = monthly.map((row) => Number(row.month.slice(5, 7)));
  const folds = Math.min(6, Math.max(1, Math.floor(monthsUsed / 3)));
  const results = [] as { model: string; mae: number; rmse: number; r2: number | null }[];
  for (const kind of ["linear", "polynomial", "multilinear", "mean"]) {
    const actual: number[] = [];
    const predicted: number[] = [];
    let valid = true;
    for (let index = monthsUsed - folds; index < monthsUsed; index += 1) {
      const fitted = fitCandidate(kind, expenses, incomes, index, calendarMonths);
      if (!fitted) {
        valid = false;
        break;
      }
      const incomeWindow = incomes.slice(Math.max(0, index - 3), index);
      const avgIncome = incomeWindow.reduce((sum, value) => sum + value, 0) / Math.max(incomeWindow.length, 1);
      const estimate = fitted(index, expenses[index - 1] ?? 0, avgIncome, calendarMonths[index] ?? 1);
      actual.push(expenses[index] ?? 0);
      predicted.push(Math.max(estimate, 0));
    }
    if (valid && actual.length > 0) results.push({ model: kind, ...modelMetrics(actual, predicted) });
  }
  const best = [...results].sort((a, b) => a.rmse - b.rmse)[0] ?? results[0];
  if (!best) {
    return { ...base, status: "insufficient_data", estimates: [], message: "Add more completed months to get a spending estimate." };
  }
  const estimates = [] as { month: string; estimate: number; low: number; high: number }[];
  const extended = [...expenses];
  const extendedIncome = [...incomes];
  const fitted = fitCandidate(best.model, extended, extendedIncome, monthsUsed, calendarMonths);
  if (!fitted) {
    return { ...base, status: "insufficient_data", estimates: [], message: "Add more completed months to get a spending estimate." };
  }
  for (let step = 1; step <= 2; step += 1) {
    const index = monthsUsed + step - 1;
    const incomeWindow = extendedIncome.slice(-3);
    const avgIncome = incomeWindow.reduce((sum, value) => sum + value, 0) / Math.max(incomeWindow.length, 1);
    const nextMonth = shiftMonth(lastMonth, step);
    const estimate = Math.max(fitted(index, extended[index - 1] ?? 0, avgIncome, Number(nextMonth.slice(5, 7))), 0);
    const margin = best.rmse * Math.sqrt(step);
    estimates.push({ month: nextMonth, estimate, low: Math.max(estimate - margin, 0), high: estimate + margin });
    extended.push(estimate);
    extendedIncome.push(avgIncome);
  }
  return { ...base, status: "ok", model: best.model, candidates: results, estimates, message: `Estimated with ${best.model} (lowest walk-forward validation RMSE).` };
}

export function forecastByCategory(transactions: FinanceTransaction[], today = new Date()) {
  const monthly = completedMonthlyTotals(transactions, today);
  if (monthly.length < 3) return {} as Record<string, number>;
  const index = monthly.map((_, position) => position);
  const out: Record<string, number> = {};
  for (const category of CATEGORIES) {
    const values = monthly.map((row) => transactions
      .filter((transaction) => transaction.transaction_type === "expense" && transaction.category === category && monthKey(transaction.transaction_date) === row.month)
      .reduce((sum, transaction) => sum + Number(transaction.amount), 0));
    const coefficients = fitRegression(index.map((value) => [value]), values);
    out[category] = Math.max(predictRegression(coefficients, [index.length]), 0);
  }
  return out;
}

export function generateInsights(
  transactions: FinanceTransaction[],
  budgets: FinanceBudget[],
  month: string,
  today = new Date(),
) {
  const items = [] as { type: string; text: string }[];
  const spending = categorySpend(transactions, month);
  const total = spending.reduce((sum, row) => sum + row.amount, 0);
  if (total > 0) {
    const top = spending[0];
    if (top) items.push({ type: "top_category", text: `Your highest spending category in ${month} is ${top.category} (${formatAmount(top.amount, true)}, ${Math.round((top.amount / total) * 100)}% of expenses).` });
  } else if (transactions.length > 0) {
    items.push({ type: "info", text: `No expenses recorded for ${month} yet.` });
  }

  const completeMonth = month >= currentMonth(today) ? shiftMonth(currentMonth(today), -1) : month;
  const currentSpend = categorySpend(transactions, completeMonth);
  const previousSpend = categorySpend(transactions, shiftMonth(completeMonth, -1));
  const currentTotal = currentSpend.reduce((sum, row) => sum + row.amount, 0);
  for (const row of currentSpend) {
    const previous = previousSpend.find((item) => item.category === row.category)?.amount ?? 0;
    if (previous > 0 && row.amount >= previous * 1.2 && row.amount - previous > 0.03 * Math.max(currentTotal, 1)) {
      items.push({ type: "increase", text: `Your ${row.category.toLowerCase()} expenses increased by ${Math.round((row.amount / previous - 1) * 100)}% in ${completeMonth} compared with the previous month (${formatAmount(previous, true)} → ${formatAmount(row.amount, true)}).` });
    } else if (previous > 0 && row.amount <= previous * 0.8 && previous - row.amount > 0.03 * Math.max(currentTotal, 1)) {
      items.push({ type: "decrease", text: `Good news: ${row.category.toLowerCase()} spending dropped ${Math.round((1 - row.amount / previous) * 100)}% in ${completeMonth} versus the month before.` });
    }
  }

  for (const budget of budgetStatus(budgets, transactions, month)) {
    const name = budget.category === "ALL" ? "overall budget" : `${budget.category} budget`;
    if (budget.status === "exceeded") items.push({ type: "budget_exceeded", text: `You have exceeded your ${name}: ${formatAmount(budget.spent, true)} spent of ${formatAmount(Number(budget.limit_amount), true)} (${Math.round(budget.usedPct)}%). Consider reviewing these expenses.` });
    else if (budget.status === "warning") items.push({ type: "budget_warning", text: `You have used ${Math.round(budget.usedPct)}% of your ${name}; only ${formatAmount(budget.remaining, true)} remains.` });
  }

  const income = amountForMonth(transactions, month, "income");
  if (income > 0 && total > 0) {
    const savingsRate = ((income - total) / income) * 100;
    if (savingsRate < 0) items.push({ type: "savings", text: `Your expenses exceed your income this month by ${formatAmount(-((income - total)), true)}.` });
    else if (savingsRate < 10) items.push({ type: "savings", text: `You are saving about ${Math.round(savingsRate)}% of your income this month — a common rule of thumb is 20%.` });
    else items.push({ type: "savings", text: `You are saving about ${Math.round(savingsRate)}% of your income this month.` });
  }

  const forecast = forecastSpending(transactions, today);
  const nextEstimate = forecast.estimates[0];
  if (forecast.status === "ok" && nextEstimate && nextEstimate.low !== null && nextEstimate.high !== null) {
    items.push({ type: "forecast", text: `Estimated spending for ${nextEstimate.month}: about ${formatAmount(nextEstimate.estimate, true)} (likely range ${formatAmount(nextEstimate.low, true)}–${formatAmount(nextEstimate.high, true)}). This is an estimate, not a guarantee.` });
  } else if (forecast.status === "insufficient_data" && transactions.length > 0) {
    items.push({ type: "info", text: forecast.message ?? "Add completed months to get a spending estimate." });
  }

  const categoryForecast = forecastByCategory(transactions, today);
  const nextCategory = Object.entries(categoryForecast).sort((a, b) => b[1] - a[1])[0];
  if (nextCategory && nextCategory[0] && nextCategory[1] > 0) {
    items.push({ type: "forecast", text: `Next month, ${nextCategory[0].toLowerCase()} is expected to be your largest category (~${formatAmount(nextCategory[1], true)}).` });
  }

  if (transactions.length === 0) items.splice(0, items.length, { type: "info", text: "Add a few transactions to receive personalised insights." });
  items.push({ type: "disclaimer", text: "Insights are educational and are not professional financial advice." });
  return items;
}

export function chatbotReply(message: string) {
  const text = message.toLowerCase();
  if (/\b(add|record|enter|new)\b.*\b(transaction|expense|income)\b|\bhow.*(add|log)\b/.test(text)) {
    return "Open Transactions, enter the date, description, amount and type, then save. Expenses can be categorized automatically, or you can choose a category yourself.";
  }
  if (/categor/.test(text)) return "Expense categories are predicted from transaction descriptions. If a prediction is wrong, choose a different category while editing the transaction. Categories: Food, Transport, Shopping, Bills, Entertainment, Health, Education and Other.";
  if (/\bbudget/.test(text)) return "Open Budgets, choose a month and set an overall limit or a limit for one category. You'll see the percentage used, with a warning at 80% and an alert above 100%.";
  if (/forecast|predict|estimate|future/.test(text)) return "Spending estimates compare simple regression models using earlier months, and need at least 3 completed months for a regression forecast. They are estimates, not guarantees.";
  if (/\binsight/.test(text)) return "Insights highlight spending categories, month-to-month changes, budget usage and savings. They are educational, not professional financial advice.";
  if (/dashboard|balance|report|chart/.test(text)) return "The Overview shows income, expenses, balance, spending by category and a monthly trend with an estimate.";
  if (/password|security|privacy|safe|secure/.test(text)) return "Your finance records are private to your signed-in account. The app uses Lovable Cloud sign-in and account-scoped data access.";
  if (/edit|update|delete|remove|change/.test(text)) return "Open Transactions and use the edit or delete controls beside a transaction.";
  if (/search|filter|find/.test(text)) return "Use the search box and transaction type, category and month filters at the top of the Transactions list.";
  if (/invest|stock|tax|loan|advice/.test(text)) return "This app is educational and does not give investment, tax, loan or other professional financial advice. Please consult a qualified advisor.";
  if (/\b(hi|hello|hey|help)\b/.test(text)) return "Hi! I can explain how to add transactions, categories, budgets, forecasts, insights and account privacy. What would you like to know?";
  return "I can answer general questions about this app — try asking about adding transactions, categories, budgets, forecasts, insights, the dashboard or security.";
}