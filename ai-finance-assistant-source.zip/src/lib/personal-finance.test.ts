import { describe, expect, it } from "vitest";
import { analyzePersonalFinance, personalFinanceReply } from "./personal-finance";
import type { FinanceTransaction, FinanceBudget } from "./finance";

const today = new Date(2026, 10, 8);
const food: FinanceTransaction = {
  id: "food",
  transaction_date: "2026-11-02",
  description: "groceries",
  amount: 2000,
  category: "Food",
  transaction_type: "expense",
};
const overall: FinanceBudget = {
  id: "all",
  month_start: "2026-11-01",
  category: "ALL",
  limit_amount: 2500,
};
const rows: FinanceTransaction[] = [
  {
    id: "income",
    transaction_date: "2026-11-01",
    description: "salary",
    amount: 20000,
    category: "Income",
    transaction_type: "income",
  },
  {
    id: "food",
    transaction_date: "2026-11-02",
    description: "groceries",
    amount: 2000,
    category: "Food",
    transaction_type: "expense",
  },
  {
    id: "old",
    transaction_date: "2026-10-02",
    description: "bus",
    amount: 1500,
    category: "Transport",
    transaction_type: "expense",
  },
];
const budgets: FinanceBudget[] = [overall];

describe("personal record analysis", () => {
  it("calculates the required 20000 income, 2000 expenses and 18000 remainder from records", () => {
    expect(analyzePersonalFinance(rows, budgets, "2026-11", today)).toMatchObject({
      income: 20000,
      expenses: 2000,
      remaining: 18000,
      categories: [{ category: "Food", amount: 2000 }],
    });
  });
  it("changes calculations when actual records change rather than using fixed examples", () => {
    expect(
      analyzePersonalFinance(
        [...rows, { ...food, id: "extra", amount: 4000 }],
        [],
        "2026-11",
        today,
      ).remaining,
    ).toBe(14000);
  });
  it("compares a 5000 savings goal with actual surplus and remaining overall budget", () => {
    const answer = personalFinanceReply(
      "Can I save ₹5,000 this month?",
      rows,
      budgets,
      "2026-11",
      today,
    );
    expect(answer.savings).toEqual({
      goal: 5000,
      covered: true,
      remainderAfterGoal: 13000,
      additionalSpendingLimit: 500,
    });
  });
  it("returns a budget warning at 80 percent", () => {
    expect(analyzePersonalFinance(rows, budgets, "2026-11", today).budgets[0]).toMatchObject({
      usedPct: 80,
      status: "warning",
    });
  });
  it("returns exceeded only above 100 percent", () => {
    expect(
      analyzePersonalFinance(rows, [{ ...overall, limit_amount: 1999 }], "2026-11", today)
        .budgets[0]?.status,
    ).toBe("exceeded");
    expect(
      analyzePersonalFinance(rows, [{ ...overall, limit_amount: 2000 }], "2026-11", today)
        .budgets[0]?.status,
    ).toBe("warning");
  });
  it("uses current month for this month even with another month selected", () => {
    expect(
      personalFinanceReply("How much did I spend this month?", rows, [], "2026-10", today).facts
        .expenses,
    ).toBe(2000);
  });
  it("does not invent spending when there are no records", () => {
    expect(analyzePersonalFinance([], [], "2026-11", today)).toMatchObject({
      recordCount: 0,
      income: 0,
      expenses: 0,
      categories: [],
    });
  });
  it("never represents a stale historical forecast as next month's estimate", () => {
    const stale: FinanceTransaction[] = [{ ...food, transaction_date: "2026-07-02" }];
    const reply = personalFinanceReply(
      "Predict next month's expenses",
      stale,
      [],
      "2026-11",
      today,
    );
    expect(reply.facts.forecast.estimates.some((row) => row.month === "2026-12")).toBe(false);
  });
  it("produces next-month estimates from sufficient recent monthly records", () => {
    const history = [7, 8, 9, 10].map((month, index) => ({
      ...food,
      id: String(index),
      transaction_date: `2026-${String(month).padStart(2, "0")}-02`,
      amount: 1000 + index * 100,
    }));
    const forecast = personalFinanceReply(
      "Predict next month's expenses",
      history,
      [],
      "2026-11",
      today,
    ).facts.forecast;
    expect(forecast.status).toBe("ok");
    expect(forecast.estimates.find((row) => row.month === "2026-12")?.estimate).toBeCloseTo(1500);
  });
});
