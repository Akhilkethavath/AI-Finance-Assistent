import { createServerFn } from "@tanstack/react-start";
import { setResponseHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { personalFinanceReply } from "./personal-finance";
import type { FinanceTransaction } from "./finance";

export const askPersonalFinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        question: z.string().trim().min(1).max(500),
        month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/),
      })
      .strict()
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    setResponseHeader("Cache-Control", "no-store");
    const transactions: FinanceTransaction[] = [];
    for (let from = 0; ; from += 1000) {
      const result = await context.supabase
        .from("transactions")
        .select("id, transaction_date, description, amount, transaction_type, category")
        .eq("user_id", context.userId)
        .order("id")
        .range(from, from + 999);
      if (result.error) throw new Error("Could not read your transactions. Please try again.");
      const page = (result.data ?? []) as FinanceTransaction[];
      transactions.push(...page);
      if (page.length < 1000) break;
    }
    const budgets = [];
    for (let from = 0; ; from += 1000) {
      const result = await context.supabase
        .from("budgets")
        .select("id, month_start, category, limit_amount")
        .eq("user_id", context.userId)
        .order("id")
        .range(from, from + 999);
      if (result.error) throw new Error("Could not read your budgets. Please try again.");
      const page = result.data ?? [];
      budgets.push(...page);
      if (page.length < 1000) break;
    }
    const reply = personalFinanceReply(data.question, transactions, budgets, data.month);
    return { text: reply.text, month: reply.facts.month, checkedAt: new Date().toISOString() };
  });
