import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

export const Route = createFileRoute("/api/voice/speak")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const voice = await import("@/lib/voice.server");
        if (!(await voice.verifyVoiceCaller(request))) return Response.json({ error: "Please sign in again." }, { status: 401 });
        const parsed = z.object({ text: z.string().trim().min(1).max(voice.MAX_SPEECH_CHARS) }).strict().safeParse(await request.json().catch(() => null));
        if (!parsed.success) return Response.json({ error: "Nothing to read aloud." }, { status: 400 });
        try {
          const upstream = await voice.requestSpeech(parsed.data.text, request.signal);
          return new Response(upstream.body, {
            status: upstream.status,
            headers: { "Content-Type": upstream.headers.get("content-type") ?? "text/event-stream", "Cache-Control": "no-cache" },
          });
        } catch (error) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          throw error;
        }
      },
    },
  },
});
