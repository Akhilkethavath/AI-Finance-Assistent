import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/voice/transcribe")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const voice = await import("@/lib/voice.server");
        if (!(await voice.verifyVoiceCaller(request))) return Response.json({ error: "Please sign in again." }, { status: 401 });
        const declared = Number(request.headers.get("content-length") ?? "0");
        if (!declared || declared > voice.MAX_AUDIO_BYTES + 64 * 1024) {
          return Response.json({ error: "Recording is too long. Please ask a shorter question." }, { status: 413 });
        }
        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof File) || file.size < 2048 || file.size > voice.MAX_AUDIO_BYTES || !file.type.startsWith("audio/")) {
          return Response.json({ error: "We couldn't hear that. Please record again." }, { status: 400 });
        }
        const upstream = await voice.transcribeAudio(file);
        return new Response(upstream.body, {
          status: upstream.status,
          headers: { "Content-Type": upstream.headers.get("content-type") ?? "text/event-stream", "Cache-Control": "no-cache" },
        });
      },
    },
  },
});
